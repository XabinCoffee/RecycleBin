<?php
include 'lib/nusoap.php';

?>